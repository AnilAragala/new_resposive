import React, { useContext, useState, useEffect } from "react";
import { Route, withRouter } from "react-router-dom";
import { MenuContext } from "react-flexible-sliding-menu";
import logo from "./images/abbott.png";
import Dashboard from "./components/Dashboard";
import Assets from "./components/Assets";
import MainMenu from "./components/MainMenu";

function App(props) {
  const { toggleMenu } = useContext(MenuContext);
  const [menuDis, setMenuDis] = useState("grid");
  const [ menuIconClass, setMenuIconClass] = useState("none")

  const changeMenuProperty = () => {
    toggleMenu();
    setMenuDis("grid");
  }

  const changeIconProperty = () =>{
    let menuIcon = menuIconClass === "none" ? "inline" : "none";
    setMenuIconClass(menuIcon);
  }

  const hideMenuProperty = () => {
    setMenuDis("none");
    console.log(menuDis);
  }


  useEffect(()=>{
    setMenuDis("grid");
  },[props.location])

  return (
    <div className="App">
      <MainMenu menuDis={menuDis} menuIconClass={menuIconClass} hideMenuProperty={hideMenuProperty} changeIconProperty={changeIconProperty} />
      <i className="fa fa-angle-double-left left_menu" aria-hidden="true" onClick={changeMenuProperty}></i>
      <div className="container">
        <img className="abbott_logo" alt="Abbott Logo" src={logo} />
        <span className="portal">Self Service Portal</span>
        <input type="search" className="search_input form-control" placeholder="Search"></input>
        <i className="fa fa-bell" aria-hidden="true"></i>
      </div>
      <Route exact path="/" component={Dashboard} />
      <Route path="/dashboard" component={Dashboard} />
      <Route path="/assets" component={Assets} />
      
    </div>
  );
}

export default withRouter(App);
