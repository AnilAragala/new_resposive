import React from "react";
import "./css/catalog.css";

function CatalogServices() {
  return (
    <div className="catalog_dashboard">
      <h3>Catalog of Services</h3>
      <div className="container_service">
      <i className="fa fa-cube" aria-hidden="true"></i>
        <h4>Container as a Service</h4>
        <p>
          Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do
          eiusmod tempor incididunt ut labore et dolore magna aliqua.
        </p>
      </div>
      <div className="infra_service">
      <i className="fa fa-line-chart" aria-hidden="true"></i>
        <h4>Infrastructure of Services</h4>
        <p>
          Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do
          eiusmod tempor incididunt ut labore et dolore magna aliqua.
        </p>
      </div>
    </div>
  );
}

export default CatalogServices;
