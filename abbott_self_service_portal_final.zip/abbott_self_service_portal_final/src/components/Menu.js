import React, { useContext } from "react";
import { NavLink } from "react-router-dom";
import { MenuContext } from "react-flexible-sliding-menu";
import profileImage from "../images/profile.jpeg";

function Menu() {
  const { closeMenu } = useContext(MenuContext);
  return (
    <div className="Menu">
      <img className="profile_img" alt="profile pic" src={profileImage} />
      <br></br>
      <br></br>
      <span className="welcome">Welcome back</span>
      <h2>Christopher</h2>
      <i className="fa fa-pencil" aria-hidden="true"></i>
      <nav onClick={closeMenu}>
        <NavLink to="/">
          <i className="fa fa-th-large" aria-hidden="true"></i>
          <span>My Dashboard</span>
        </NavLink>
        <NavLink to="/assets">
          <i className="fa fa-window-restore" aria-hidden="true"></i>
          <span>Manage Assets</span>
        </NavLink>
        <NavLink to="gallery">
          <i className="fa fa-cloud" aria-hidden="true"></i>
          <span>Cloud Economics</span>
        </NavLink>
        <NavLink to="gallery">
          <i className="fa fa-tasks" aria-hidden="true"></i>
          <span>Task</span>
        </NavLink>
        <NavLink to="gallery">
        <i className="fa fa-comments" aria-hidden="true"></i>
          <span>Feedback</span>
        </NavLink>
        <hr></hr>
        <NavLink to="gallery">
          <i className="fa fa-lock" aria-hidden="true"></i>
          <span>Administration</span>
        </NavLink>
        <hr></hr>
        <NavLink to="gallery">
          <i className="fa fa-bell" aria-hidden="true"></i>
          <span>Notification</span>
        </NavLink>
        <NavLink to="gallery">
          <i className="fa fa-cog" aria-hidden="true"></i>
          <span>Settings</span>
        </NavLink>
        <NavLink to="gallery">
        <i className="fa fa-sign-out" aria-hidden="true"></i>
          <span>Logout</span>
        </NavLink>
      </nav>
    </div>
  );
}

export default Menu;
