import { useState, useEffect } from "react";
import React from 'react'
import Pagination from "./Pagination"
import {assetsInfo, defaultOptions,data} from "./products/AssetsInfo"
import "./css/assets.css"
import {useForm} from "react-hook-form";
import MainMenu from "./MainMenu";

function Assets() {
  const [posts] = useState(assetsInfo);
  const [currentPage, setCurrentPage] = useState(1);
  const [postsPerPage] = useState(10);
  const [options, setoptions] = useState([...defaultOptions]);
  const [selectedFilters, setSelectedFilters] = useState([...defaultOptions]);
  const [styleDisplay, setStyleDisplay] = useState("none");

  const { register, handleSubmit } = useForm();
  const onSubmit = () => {
    options.length > 0 ? setSelectedFilters([...options]) : setSelectedFilters([...defaultOptions])
    setStyleDisplay("none");
    if(!options.length){
      setoptions([...defaultOptions]);
    }
  };

  const setDiplayProp = () => {
    setStyleDisplay("block");
  }

const paginate = (pageNumber) => setCurrentPage(pageNumber);
const onChangeOptions = (e,c)=>{
  console.log(e.target.checked,c);
  e.target.checked ? setoptions([...options,c]) : setoptions(options.filter((op)=>op.value !== c.value))
}
const indexOfLastSource = currentPage * postsPerPage;
const indexOfFirstSource = indexOfLastSource - postsPerPage;
const currentPosts = posts.slice(indexOfFirstSource, indexOfLastSource);

    return (
      
        <div className="main_div">
          {/* <MainMenu /> */}
            <div className="asset_header">
                <h2>Manage Assets</h2>
                    <button>Opt-Out</button>
                    <button>Re-certify</button>
            </div>
            <div className="my_resources">
                <h4>My Resources</h4>
                <p>
                    <span>Date</span>
                    <span>Role</span>
                    <span>A-Z</span>
                    </p>
                    <form onSubmit={handleSubmit(onSubmit)} style={{display:styleDisplay}}>
                      <fieldset>
                        <legend>Please Select Header </legend>
                        {
                          data.map(
                            (c,i) => <label key={i}><input type="checkbox" 
                            checked={!!options.find(o => o.value === c.value)}
                            onChange={(e)=>onChangeOptions(e,c)}
                            name="selectedOptions" 
                            ref={register} />{c.label}</label>
                          )
                        }
                        <input type="submit" />
                      </fieldset>
                      
                      </form>

            </div>
            <i className="fa fa-bars" aria-hidden="true" onClick={setDiplayProp}></i>
            <table id="commontable">
                <tbody>
                    <tr className="border_bottom">{selectedFilters.map((val, index) => { 
                        return <th key={index}>{val.label}</th>}) }</tr>
                        {currentPosts.map((currentPost, index) => {
                        const { id } = currentPost; //destructuring
                      return ( 
                          <tr key={currentPost.id}>
                            {selectedFilters.map((val, index)=>{
                              return <td key={`id-${index}`}>{currentPost[val.value]}</td>
                            })}
                    </tr>
                  );
                })}
                </tbody>
             </table>
            <Pagination
              postsPerPage={postsPerPage}
              totalPosts={posts.length}
              paginate={paginate}
            />
        </div>
    )
}

export default Assets
