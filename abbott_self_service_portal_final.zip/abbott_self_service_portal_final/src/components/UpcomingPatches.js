import React from "react";

function UpcomingPatches() {
  return (
    <div className="upcoming_patches">
      <h3>Upcoming Patches</h3>
      <div className="patch_dates">
        <span className="date">13</span>
        <br></br>
        <span>Nov 2020</span>
        <br></br>
        <span>11:12</span>
      </div>
      <div className="patch_dates">
        <span className="date">30</span>
        <br></br>
        <span>Nov 2020</span>
        <br></br>
        <span>09:21</span>
      </div>
      <div className="patch_dates">
        <span className="date">13</span>
        <br></br>
        <span>Nov 2020</span>
        <br></br>
        <span>13:23</span>
      </div>
      <p>
        Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod
        tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim
        veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea
        commodo consequat. Duis aute irure dolor in reprehenderit in voluptate
        velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint
        occaecat cupidatat non proident, sunt in culpa qui officia deserunt
        mollit anim id est laborum.
      </p>
      <div className="upcoming_tasks">
        <br></br>
        <h2>Upcoming Tasks</h2>
        <p>
          Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do
          eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad
          minim veniam, quis nostrud exercitation ullamco laboris nisi ut
          aliquip ex ea commodo consequat. Duis aute irure dolor in
          reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla
          pariatur. Excepteur sint occaecat cupidatat non proident, sunt in
          culpa qui officia deserunt mollit anim id est laborum.
        </p>
        <br></br>
        <span className="severity"> Severity | Major</span>
        <br></br>
        <br></br>
      </div>
    </div>
  );
}

export default UpcomingPatches;
