import React from "react";

const Pagination = ({ postsPerPage, totalPosts, paginate }) => {
  const pageNumbers = [];

  for (let i = 1; i <= Math.ceil(totalPosts / postsPerPage); i++) {
    pageNumbers.push(i);
  }

  return (
    <nav>
      <ul className="pagination">
          <li>
          <a onClick={() => paginate(1)} href="/assets/!#" className="page-link">
          {/* <i className="fa fa-angle-double-left" aria-hidden="true"></i> */}
          {`<<`}
            </a>
          </li>
        {pageNumbers.map((number) => (
          <li key={number} className="page-item">
            <a onClick={() => paginate(number)} href="/assets/!#" className="page-link">
              {number}
            </a>
          </li>
        ))}
        <li>
          <a onClick={() => paginate(pageNumbers.length)} href="/assets/!#" className="page-link">
          {/* <i className="fa fa-angle-double-right" aria-hidden="true"></i> */}
          {`>>`}
            </a>
          </li>
      </ul>
    </nav>
  );
};

export default Pagination;
