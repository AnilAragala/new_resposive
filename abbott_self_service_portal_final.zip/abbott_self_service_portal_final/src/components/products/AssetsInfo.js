export const assetsInfo = [
    {
      id: 1,
      server: "server1",
      status:"deployed",
      description: "Lorem ipsum dolor sit amet, conset",
      role: "admin",
      category:"On Promises Resources",
      certification_date: "10 days remainig",
      patch_date:"23/02/2021"
    },
    {
      id: 2,
      server: "server2",
      status:"deployed",
      description: "Lorem ipsum dolor sit amet, conset",
      role: "admin",
      category:"On Promises Resources",
      certification_date: "10 days remainig",
      patch_date:"29/01/2021"
    },
    {
      id: 3,
      server: "server3",
      status:"deployed",
      description: "testing ux screens",
      role: "supporter",
      category:"On Promises Resources",
      certification_date: "10 days remainig",
      patch_date:"15/02/2021"
    },
    {
      id: 4,
      server: "server4",
      status:"deployed",
      description: "testing ux screens",
      role: "admin",
      category:"On Promises Resources",
      certification_date: "10 days remainig",
      patch_date:"27/01/2021"
    },
    {
      id: 5,
      server: "server5",
      status:"deployed",
      description: "testing ux screens",
      role: "admin",
      category:"On Promises Resources",
      certification_date: "10 days remainig",
      patch_date:"24/02/2021"
    },
    {
      id: 6,
      server: "server6",
      status:"deployed",
      description: "testing ux screens",
      role: "admin",
      category:"On Promises Resources",
      certification_date: "10 days remainig",
      patch_date:"21/01/2021"
    },
    {
      id: 7,
      server: "server7",
      status:"deployed",
      description: "testing ux screens",
      role: "admin",
      category:"On Promises Resources",
      certification_date: "10 days remainig",
      patch_date:"20/02/2021"
    },
    {
      id: 8,
      server: "server8",
      status:"deployed",
      description: "testing ux screens",
      role: "admin",
      category:"On Promises Resources",
      certification_date: "10 days remainig",
      patch_date:"19/01/2021"
    },
    {
      id: 9,
      server: "server9",
      status:"deployed",
      description: "testing ux screens",
      role: "admin",
      category:"On Promises Resources",
      certification_date: "10 days remainig",
      patch_date:"17/02/2021"
    },
    {
      id: 10,
      server: "server10",
      status:"deployed",
      description: "testing ux screens",
      role: "admin",
      category:"On Promises Resources",
      certification_date: "10 days remainig",
      patch_date:"30/02/2021"
    },
    {
      id: 11,
      server: "server11",
      status:"deployed",
      description: "testing ux screens",
      role: "admin",
      category:"On Promises Resources",
      certification_date: "10 days remainig",
      patch_date:"06/04/2021"
    },
    {
      id: 12,
      server: "server12",
      status:"deployed",
      description: "testing ux screens",
      role: "admin",
      category:"On Promises Resources",
      certification_date: "10 days remainig",
      patch_date:"15/02/2021"
    },
    {
      id: 13,
      server: "server13",
      status:"deployed",
      description: "testing ux screens",
      role: "supporter",
      category:"On Promises Resources",
      certification_date: "10 days remainig",
      patch_date:"01/01/2021"
    },
    {
      id: 14,
      server: "server14",
      status:"deployed",
      description: "testing ux screens",
      role: "admin",
      category:"On Promises Resources",
      certification_date: "20 days remainig",
      patch_date:"16/03/2021"
    },
    {
      id: 15,
      server: "server15",
      status:"deployed",
      description: "testing ux screens",
      role: "admin",
      category:"On Promises Resources",
      certification_date: "10 days remainig",
    },
    {
      id: 16,
      server: "server16",
      status:"deployed",
      description: "testing ux screens",
      role: "admin",
      category:"On Promises Resources",
      certification_date: "100 days remainig",
      patch_date:"22/01/2021"
    },
    {
      id: 17,
      server: "server17",
      status:"deployed",
      description: "testing ux screens",
      role: "supporter",
      category:"On Promises Resources",
      certification_date: "10 days remainig",
      patch_date:"13/04/2021"
    },
    {
      id: 18,
      server: "server18",
      status:"deployed",
      description: "testing ux screens",
      role: "admin",
      category:"On Promises Resources",
      certification_date: "220 days remainig",
      patch_date:"13/02/2021"
    },
    {
      id: 19,
      server: "server19",
      status:"deployed",
      description: "testing ux screens",
      role: "admin",
      category:"On Promises Resources",
      certification_date: "10 days remainig",
      patch_date:"11/01/2021"
    },
    {
      id: 20,
      server: "server20",
      status:"deployed",
      description: "testing ux screens",
      role: "supporter",
      category:"On Promises Resources",
      certification_date: "10 days remainig",
      patch_date:"12/12/2020"
    },
  ];

  export const data = [
    {label: "Server", value:"server"},
    {label: "Status", value:"status"},
    {label: "Description", value:"description"},
    {label: "Category",value:"category"},
    {label: "Role",value:"role"},
    {label: "Certification",value:"certification_date"},
    {label: "PatchDate",value:"patch_date"},
  ];

  export const defaultOptions = [
    {label: "Server", value:"server"},
    {label: "Status", value:"status"},
    {label: "Description", value:"description"},
    {label: "Category",value:"category"},
    {label: "Role",value:"role"},
  ];
