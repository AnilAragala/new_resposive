import React from 'react'
import grafana from "../images/Capture.png"
import "./css/grafana.css"

function GrafanaDashboard() {
    return (
        <div className="grafana_container">
            <h4>My cloud spendings</h4>
            <div className="grafana_div">
            <img
          className="grafana"
          alt=" menu icon"
          src={grafana}
        />
            </div>
            
        </div>
    )
}

export default GrafanaDashboard
