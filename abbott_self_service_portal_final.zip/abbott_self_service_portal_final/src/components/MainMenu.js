import React, {useState, useContext, useEffect} from 'react'
import { NavLink } from "react-router-dom";
import { MenuContext } from "react-flexible-sliding-menu";
import "./css/mainmenu.css"

function MainMenu(props) {
    const { toggleMenu, closeMenu } = useContext(MenuContext);
    // const [newIconProp , setNewIconProp] = useState(props.menuDis);

// const hideMenuProperty = () =>{
//   console.log("Main Menu ",newIconProp)
//   setNewIconProp("none");
// }

// useEffect(()=>{
//   setNewIconProp("none");
// })

console.log("main menu", props)
    return (
        <>
        {/* <i className="fa fa-angle-double-left" id="close_mainmenu" style={{display:props.menuIconClass}} aria-hidden="true" onClick={()=>{closeMenu();props.changeIconProperty()}}></i> */}
        <div className="main_menu" style={{display:props.menuDis}}>
            <a onClick={()=>{toggleMenu(); props.hideMenuProperty()}}> 
              <i className="fa fa-angle-double-right" aria-hidden="true" ></i>
            </a>
            <NavLink to="/">
          <i className="fa fa-th-large" aria-hidden="true"></i>
        </NavLink>
        <NavLink to="/assets">
          <i className="fa fa-window-restore" aria-hidden="true"></i>
        </NavLink>
        <NavLink to="gallery">
          <i className="fa fa-cloud" aria-hidden="true"></i>
        </NavLink>
        <NavLink to="gallery">
          <i className="fa fa-tasks" aria-hidden="true"></i>
        </NavLink>
        <NavLink to="gallery">
        <i className="fa fa-comments" aria-hidden="true"></i>
        </NavLink>
        <NavLink to="gallery">
          <i className="fa fa-lock" aria-hidden="true"></i>
        </NavLink>
        <NavLink to="gallery">
          <i className="fa fa-bell" aria-hidden="true"></i>
        </NavLink>
        <NavLink to="gallery">
          <i className="fa fa-cog" aria-hidden="true"></i>
        </NavLink>
        <NavLink to="gallery">
        <i className="fa fa-sign-out" aria-hidden="true"></i>
        </NavLink>
        </div>
        </>
    )
}

export default MainMenu
